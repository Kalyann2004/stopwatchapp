# Stopwatch
Simple Stopwatch with Laps using HTML, CSS, &amp; vanilla JavaScript
